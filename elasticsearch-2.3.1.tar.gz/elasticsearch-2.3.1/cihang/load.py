#encoding=utf8
import os
import sys
import json
import commands
batch = sys.argv[1]
base = 'yx_zhichangai_json'
post = 'curl -XPOST http://localhost:9200/' + batch + '/case/'
for path in os.listdir(base):
    fileName = base + '/' + path 
    with open(fileName, 'r') as f:
        s = f.read()
        try:
            js = json.loads(s.encode('utf8'))
        except:
            print s, path
            js = json.loads(s)
        li = []
        for tag in js["symp_tag"]:
            li = tag
        js["symp_tag"] = li
        js["symp_text"] = js["symp_text"].strip()
        id = path.split('.html')[0]
        cmd = post + id + " -d \'%s\'" %(json.dumps(js))
        print commands.getstatusoutput(cmd)

