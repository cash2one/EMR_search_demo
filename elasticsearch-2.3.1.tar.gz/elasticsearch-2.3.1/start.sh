#!/bin/bash

WORK_PATH="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

cd ${WORK_PATH}

bin/elasticsearch -d
ps aux | grep java | grep -i ${WORK_PATH}
