#!/bin/bash

WORK_PATH="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

cd ${WORK_PATH}

ps aux | grep java | grep -i ${WORK_PATH} | awk '{print $2}' | xargs kill -9
ps aux | grep java | grep -i ${WORK_PATH}
